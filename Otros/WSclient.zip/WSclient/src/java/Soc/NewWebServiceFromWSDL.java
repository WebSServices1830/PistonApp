/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soc;

import javax.ejb.Stateless;
import javax.xml.ws.ServiceMode;
import javax.xml.ws.WebServiceProvider;

/**
 *
 * @author sebastian
 */
@Stateless
@ServiceMode(value = javax.xml.ws.Service.Mode.PAYLOAD)
@WebServiceProvider(serviceName = "StockTickerService", portName = "StockTickerPort", targetNamespace = "http://stocktrading.com/wsdl/stockTicker", wsdlLocation = "WEB-INF/wsdl/NewWebServiceFromWSDL/StockTicker.wsdl")
public class NewWebServiceFromWSDL implements javax.xml.ws.Provider<javax.xml.transform.Source> {

    public javax.xml.transform.Source invoke(javax.xml.transform.Source source) {
        //TODO implement this method
        throw new UnsupportedOperationException("Not implemented yet.");
    }
    
}
